

$(function () {
  $ ('#formdata').on('submit', function (e) {

    e.preventDefault();
        $('#btn').val('Please wait...');
        $('#btn').attr('disabled',true);
      
    $.ajax({
      url: './save_new_user',
      type: 'post',
      data: $('#formdata').serialize(),
      success: function (res) {
          // alert(res);
          $('#btn').val('Signup Now');
          $('#btn').attr('disabled',false);
          if(res==1)
          {	
          window.location.href="./index";
					$('#myform')[0].reset();
          }
          else{
						
              window.location.href="./new_user";
							$('#myform')[0].reset(); 

          }
          
      }
    });
  
  });
  });


$(function () {

  $ ('#sign_in_form').on('submit', function (e) {
  
    e.preventDefault();
          $('#btn').val('Please wait...');
          $('#btn').attr('disabled',true);
          
    $.ajax({
          type: 'post',
          url: './sign_in',
          data: $('#sign_in_form').serialize(),
          success:function(res) {
         
          $('#btn').val('Signin Now');
          $('#btn').attr('disabled',false);
          var msg = "";
          if(res==1)
          {
						// alert(res);
              window.location.href="./dashboard";
              $('#sign_in_form')[0].reset();
          }
          else
          {
						
              window.location.href="./index";
              $('#sign_in_form')[0].reset();
          }
          
      }
      
    });
  
  });
  });




$(function(){
  $('#savedata').click (function(e){
    e.preventDefault();
    var msg="";
    var fname=$('#first_name').val();
    var lname=$('#last_name').val();
    var email=$('#email').val();
    var phone=$('#phone').val();
    var city=$('#city').val();
    var address=$('#address').val();
    if (fname!= '' && lname!= '' && email!= '' && phone!= '' && city!= '' && address!= '')
     {
    if(!$.isNumeric(fname && lname))
    {
       

      $.ajax({
          url:'./save_users_data',
          type:'post',
          data:$('#myform').serialize(),
          success:function(resp)
          { 
            if(resp==1)
            { 
							alert(resp);
              $('.mymodal').modal('hide');
              $('#myform')[0].reset();
              readRecords(); 
              swal({
                title: "Success!",
                text: "Record inserted Successfully!",
                icon: "success",
                button: "Ok!",
              });

          }else
          {
            $('.mymodal').modal('show');
						$('#myform')[0].reset();
      
          }
          }

      });
    }
    else{
      msg="Please enter name not number. "
      $('#msg').html(msg);
    }

    }
    else{
      msg="All fields are required...";
      $('#msg').html(msg);
      $('#myform')[0].reset();
    
  }
  });
});

// delete
				function deletedata(id)
				{		
									
				var msg="";
				swal({
					title: "Are you sure?",
					text: "Once deleted, you will not be able to recover this file!",
					icon: "warning",
					buttons: true,
					dangerMode: true,
				})
				.then((willDelete) => {
					if (willDelete) {

						$.ajax({
							url:'./delete_user',
							type:'post',
							data:{id:id},
							success:function(data,status){
								
								readRecords();
							}
					});
						swal("Poof! Your file has been deleted!", {
							icon: "success",
						});
					} else {
						swal("Your imaginary file is safe!");
					}
				});
								
				}
// edit

function getuserdetails(id)
{
	
		$.ajax({
        url:'./get_Data_To_Edit',
        data:{id:id},
        type:'post',
        dataType:'json',
        success:function(user){
				
          $('.mymodal2').modal('show');
          $('#f_name').val(user.first_name);
          $('#l_name').val(user.last_name);
          $('#u_email').val(user.email);
          $('#u_phone').val(user.phone);
          $('#u_city').val(user.city);
          $('#u_address').val(user.address);
      },
			error:function(){
				alert('error');
			}
    });

}

function getUpdateUser()
{
 var msg=""; 
 
var hidden_id=$('#hidden_id').val();
var f_name=$('#f_name').val();
var l_name=$('#l_name').val();
var u_email=$('#u_email').val();
var u_phone=$('#u_phone').val();
var u_city=$('#u_city').val();
var u_address=$('#u_address').val();
$.ajax({

        url:'./get_Update_User',
        type:'post',
        data:{hidden_id:hidden_id,f_name:f_name,l_name:l_name,u_email:u_email,u_phone:u_phone,u_city:u_city,u_address:u_address},
        success:function(data,status){
          if(data==1)
          {
          $('.mymodal2').modal('hide');
          readRecords(); 
          swal({
            title: "Updated!",
            text: "Record update Successfully!",
            icon: "success",
            button: "Ok!",
          });
          }
          
        }
});
}




//show data
readRecords();
function readRecords()
{

var readData="readData";
$.ajax( {
    url:'./get_Data',
    type:"post",
    data:{readData:readData},
    success:function(data,status){
      $('.allData').html(data);
    }
});

}



// $(document).ready(function() {
//   var tableData=$('#example').DataTable( {
//       "processing": true,
//       "serverSide": true,
//       "ajax":{
//               url:'table.php',
//               type:'post',
              
//       }
//   });
// });

