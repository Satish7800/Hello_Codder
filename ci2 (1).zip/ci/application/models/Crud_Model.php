<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_Model extends CI_Model {

		public function save_new_user($form)
		{
			$data=$this->db->insert('admin',$form);			

			if($data==true)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		public function sign_in($email,$password)
		{
			$data=$this->db->get_where('admin',['email'=>$email,'password'=>$password]);
				$count=$data->num_rows();
				if($count>0){

					return 1;
				}
				else
				{
					return 0;
				}		
		}
		public function save_users_data($formdata)
		{
			$data=$this->db->insert('users',$formdata);
			if($data==true)
			{
				return 1;
			}
			else{
				return 0;
			}
		}
		public function get_Data()
		{
			$data=$this->db->get('users');
			$result=$data->result_array();
			return $result;
		}
		public function delete_user($id)
		{
			$d_data=$this->db->delete('users',['id'=>$id]);
			if($d_data==true)
			{
				return 1;
			}else{
				return 0;
			}
		}
		public function get_Data_To_Edit($id)
		{
			$data=$this->db->get_where('users',['id'=>$id])->row();
			return $data;
		}
		
		public function get_Update_User($formdata,$id){

			$this->db->update('users',$formdata);
			$data=$this->db->where('users',['id'=>$id]);

			if($data==true)
			{
				return 1;
			}else{
				return 0;
			}

		}

}

