<?php
          if($this->input->post('readData'))
          {
						$records=array();

            $records='<table class="table table-bordered text-center display" id="example">
            <thead>
            <tr>
                <th>Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email id</th>
                <th>Phone</th>
                <th>City</th>
                <th>Address</th>
                <th>Action</th>
                <th>Action</th>
                                    
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email id</th>
                <th>Phone</th>
                <th>City</th>
                <th>Address</th>
                <th>Action</th>
                <th>Action</th>
                                    
            </tr>
            </tfoot>
            '; 
			// print_r($res);die;
				$num=1;
                  foreach($res as $data) 
                  {
					  
                $records.='<tr>
                    <td>'.$num.'</td>
                    <td>'.$data['first_name'].'</td>
                    <td>'.$data['last_name'].'</td>    
                    <td>'.$data['email'].'</td>
                    <td>'.$data['phone'].'</td>
                    <td>'.$data['city'].'</td>
                    <td>'.$data['address'].'</td>
                    <td><button class="btn btn-warning" onclick="getuserdetails('.$data['id'].')">Edit</button></td>
                     <td><button class="btn btn-danger"  onclick="deletedata('.$data['id'].')">Delete</button></td>
                    
                 </tr>';
				 $num++;       
               }
			  
                   
                      $records.='</table>';
                ?>

                  <?php

                      echo $records;

       } 
     
      ?>


<script>
 $(document).ready(function() {
   var tableData=$('#example').DataTable( {
      
   });
 });

       </script>
