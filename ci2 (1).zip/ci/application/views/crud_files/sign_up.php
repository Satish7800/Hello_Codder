
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/style.css');?>">
	<script src="<?php echo base_url('assets/jquery/jquery.min.js')?>">"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap-auto-dismiss-alert@1.0.2/bootstrap-auto-dismiss-alert.min.js"></script>
    <script src="<?php echo base_url('assets/jquery.js')?>"></scrip>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

  
</head>
    <body class="body">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 m-auto">
					<?php if($this->session->flashdata('success')) 
					{	?>
					<div class="alert alert-success" id="success-alert">
                        <a class="close" data-dismiss="alert">×</a>
                       <?php echo $this->session->flashdata('success');
					 	$this->session->sess_destroy();  
					   ?>
                    </div>
					<?php 
					}
					else{
						?>
						<div class="alert alert-danger" id="success-alert"	>
                        <a class="close" data-dismiss="alert">×</a>
                       <?php echo $this->session->flashdata('error');
					 	$this->session->sess_destroy();  
					   ?>
                    </div>
					<?php	
					}
					?>
				    
                <div class="card" style="opacity: 0.8;">
                    <div class="card-header"><h3 style="text-align:center">Sign Up</h3></div>
                    <div class="card-body">
                        <form id="formdata"> 
                        <label for="name" class="control-label"> Name</label>
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <label for="email">Email</label>
                        <div class="form-group">
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <label for="phone">Phone</label>
                        <div class="form-group">
                            <input type="text" pattern="[1-9]{1}[0-9]{9}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"  name="phone" class="form-control" required>
                        </div>
                        <label for="name">Password</label>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <label for="confirm_password">Confirm Password</label>
                        <div class="form-group">
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>  
                        <div class="form-group">
                            <input type="submit" name="submit" id="btn" class="btn btn-primary" value="Signup Now">
                        </div>   
                        </form>   
                        <a href="<?php echo base_url('crud/index');?>" style="text-decoration:none;">Already account, click here?</a>    
                                  
                    </div>
                </div>
            </div>
        </div>
    </div>     
    
      
    </body>
</html>

<script>

	setTimeout(function(){ $(".alert").remove() }, 3000);

</script>





