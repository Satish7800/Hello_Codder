
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css');?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/jquery.js')?>"></script>
    
</head>
    <body class="body"> 
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 m-auto">
			<?php if($this->session->flashdata('success')) 
					{	?>
					<div class="alert alert-success" id="success-alert">
                        <a class="close" data-dismiss="alert">×</a>
                       <?php echo $this->session->flashdata('success');
					 	$this->session->sess_destroy();  
					   ?>
                    </div>
					<?php 
					}
					else{
						?>
						<div class="alert alert-danger"	id="success-alert">
                        <a class="close" data-dismiss="alert">×</a>
                       <?php echo $this->session->flashdata('error');
					 	$this->session->sess_destroy();  
					   ?>
                    </div>
					<?php	
					}
					?>
				   
                <div class="card" style="opacity: 0.8;">
                    <div class="card-header"><h3 style="text-align:center">Sign In</h3></div>
                    <div class="card-body">
                        <form method="post" action="" id="sign_in_form"> 
                        
                        <label for="email">Email</label>
                        <div class="form-group">
                            <input type="email" name="email" class="form-control " required>
                        </div>
                       
                        <label for="name">Password</label>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="submit" name="submit" id="btn" class="btn btn-primary" value="Signin Now">
                        </div>   
                        </form>    
						<a href="<?php echo base_url('crud/new_user');?>" style="text-decoration:none;">New user? click here</a>    
						
                     <span id="msg"></span>          
                    </div>
                </div>
            </div>
        </div>
    </div>  
              
    </body>
</html>

<script>

	  setTimeout(function(){ $(".alert").remove() }, 3000);
</script>

