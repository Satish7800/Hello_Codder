<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	public function __construct() 
	{
		parent::__construct();        		
		$this->load->model('Crud_Model');         
		 
	}
	
	public function index()
	{
		$this->load->view("crud_files/sign_in");
	}
	public function new_user()
	{
		$this->load->view('crud_files/sign_up');
	}
	public function save_new_user()
	{
		
                sleep(1);

                $this->form_validation->set_rules('name', 'Name', 'required');
				$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[admin.email]');
				$this->form_validation->set_rules('phone', 'Phone', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required',
                        array('required' => 'You must provide a %s.')
                );
                $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
                

                if ($this->form_validation->run() == true)
                {
                    $form=array(
						'name'=> $this->input->post('name'),
						'email'=> $this->input->post('email'),
						'phone'=>$this->input->post('phone'),
						'password'=>base64_encode($this->input->post('password'))
						);
						
						$data=$this->Crud_Model->save_new_user($form);
						
						if($data==true)
						{
							$this->session->set_flashdata('success', 'Record inserted successfully');
							echo 1;
						}
						else{
							$this->session->set_flashdata('error', 'Record insertion failed');
							echo 0;
						}

                }
                else
                {
						$this->session->set_flashdata('error', 'Validation Error');
						echo 0;
                }
	}
	public function sign_in()
	{
		$email=$this->input->post('email');
		$password=base64_encode($this->input->post('password'));
		
		$data=$this->Crud_Model->sign_in($email,$password);
		
		if($data==true){
			
			$this->session->set_flashdata('success','You are Logged in');
			echo 1;
		}
		else{
			$this->session->set_flashdata('error','Username or password wrong');
			echo 0;
		}
	}
	public function dashboard()
	{
		sleep(1);
	
		$this->load->view('crud_files/welcome');
	}
	public function save_users_data()
	{
		if($this->input->post())
		{
				$formdata=array(
				'first_name'=>$this->input->post('first_name'),
				'last_name'=>$this->input->post('last_name'),
				'email'=>$this->input->post('email'),
				'phone'=>$this->input->post('phone'),
				'city'=>$this->input->post('city'),
				'address'=>$this->input->post('address')
				);

				$data=$this->Crud_Model->save_users_data($formdata);
				if($data==true){
			
					$this->session->set_flashdata('success','Record Saved');
					echo 1;
				}
				else{
					$this->session->set_flashdata('error','Record not Saved');
					echo 0;
				}
		}


	}
		public function get_Data()
		{
			$data['res']=$this->Crud_Model->get_Data();
			// print_r($data);die;
			$this->load->view('crud_files/table',$data);

		}
		public function delete_user()
		{        
				$deleted_data=$this->Crud_Model->delete_user($_POST['id']);
				if($deleted_data==true)
				{
					echo 1;
				}
				else
				{
					echo 0;
				}
		}
		public function get_Data_To_Edit()
		{
			$data=$this->Crud_Model->get_Data_To_Edit($_POST['id']);
			if($data==true)
			{	
			
				echo json_encode($data);
				
			}else{
				echo 0;
			}
		}
		public function get_Update_user(){

			print_r($_POST);die;
					if($_POST['hiddenid']){
						$id=$_POST['hiddenid'];
						$formdata=array(
							'first_name'=>$this->input->post('f_name'),	
							'last_name'=>$this->input->post('l_name'),
							'email'=>$this->input->post('u_email'),
							'phone'=>$this->input->post('u_phone'),
							'city'=>$this->input->post('u_city'),
							'address'=>$this->input->post('u_address')	
						);

					$data=$this->Crud_Model->get_Update_User($formdata,$id);
						if($data==true)
						{
							echo 1;
						}else{
							echo 0;
						}
					}
					else{
						echo "id not found.";	
					}
		}












	public function logout()
	{
		// $this->session->session_destroy();
		// redirect('crud/index');
	}



}
